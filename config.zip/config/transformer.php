<?php

return [
    'namespace'      => 'App\\Models\\Transformers\\',
    'filter_postfix' => 'Transformer',
];
