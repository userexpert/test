<?php

return [
    'namespace' => 'App\\Models\\Filters\\',
    'filter_postfix' => 'Filter',
];
